# Kurofy Flutter App
Developer: @kuroz4ph | t.me/kuroz4ph

## Setup

### 1. Install dependencies
```bash
flutter pub get
```

### 2. Set API URL
Edit `lib/utils/theme.dart`:
```dart
const kApiBase = 'http://YOUR_SERVER_IP:3000/api';
```
Ganti `YOUR_SERVER_IP` dengan IP VPS/server kamu.

### 3. Download font Rajdhani
Download dari: https://fonts.google.com/specimen/Rajdhani
Taruh file .ttf ke folder: `assets/fonts/`
- Rajdhani-Regular.ttf
- Rajdhani-Bold.ttf
- Rajdhani-SemiBold.ttf
- Rajdhani-Medium.ttf
- Rajdhani-Light.ttf

### 4. App icon
Ganti icon di: `android/app/src/main/res/mipmap-*/ic_launcher.png`
Atau pakai flutter_launcher_icons:
```bash
flutter pub add flutter_launcher_icons
flutter pub run flutter_launcher_icons
```

### 5. Build APK
```bash
flutter build apk --release
```
APK output: `build/app/outputs/flutter-apk/Kurofy-1.0.0.apk`

## Struktur Project
```
lib/
├── main.dart
├── models/models.dart
├── providers/
│   ├── auth_provider.dart
│   └── player_provider.dart
├── services/api_service.dart
├── utils/theme.dart
├── widgets/
│   ├── widgets.dart
│   └── mini_player.dart
└── screens/
    ├── main_screen.dart
    ├── auth/ (splash, login, register)
    ├── home/
    ├── search/
    ├── library/
    ├── profile/
    ├── player/ (full player)
    ├── artist/
    ├── album/
    └── playlist/
```

## Fitur
- Login & Register
- Home (Trending, New Releases, Charts, Artists, Playlists)
- Search (Songs, Artists, Albums)
- Music Player (Mini + Full Screen)
- Background Playback
- Queue System
- Shuffle & Repeat
- Lyrics
- Like Songs
- Play History
- Create & Manage Playlists
- Artist & Album Pages
- Follow Artists/Playlists
- Profile & Settings
