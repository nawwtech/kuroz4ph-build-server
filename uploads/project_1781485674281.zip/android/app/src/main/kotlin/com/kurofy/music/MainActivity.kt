package com.kurofy.music
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
