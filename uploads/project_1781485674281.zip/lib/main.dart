import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'providers/player_provider.dart';
import 'screens/auth/splash_screen.dart';
import 'utils/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await JustAudioBackground.init(
    androidNotificationChannelId:   'com.kurofy.music.channel.audio',
    androidNotificationChannelName: 'Kurofy Music',
    androidNotificationOngoing:     true,
    androidShowNotificationBadge:   true,
  );

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:           Colors.transparent,
    statusBarIconBrightness:  Brightness.light,
    systemNavigationBarColor: Color(0xFF0A0A0F),
  ));

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()..init()),
        ChangeNotifierProvider(create: (_) => PlayerProvider()),
      ],
      child: const KurofyApp(),
    ),
  );
}

class KurofyApp extends StatelessWidget {
  const KurofyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title:        'Kurofy',
      debugShowCheckedModeBanner: false,
      theme:        kTheme,
      home:         const SplashScreen(),
    );
  }
}
