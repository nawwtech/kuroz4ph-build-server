// ── Song ─────────────────────────────────────────────────────────────────────
class Song {
  final String id, title, artists, album, albumId;
  final String image, streamUrl, downloadUrl;
  final int duration;
  final String year, language, lyricsId;
  final bool hasLyrics, explicit;

  const Song({
    required this.id, required this.title, required this.artists,
    this.album = '', this.albumId = '',
    this.image = '', this.streamUrl = '', this.downloadUrl = '',
    this.duration = 0, this.year = '', this.language = '',
    this.lyricsId = '', this.hasLyrics = false, this.explicit = false,
  });

  factory Song.fromJson(Map<String, dynamic> j) => Song(
    id:          j['id']          ?? '',
    title:       j['title']       ?? j['name'] ?? '',
    artists:     j['artists']     ?? j['subtitle'] ?? '',
    album:       j['album']       ?? '',
    albumId:     j['albumId']     ?? '',
    image:       j['image']       ?? '',
    streamUrl:   j['streamUrl']   ?? '',
    downloadUrl: j['downloadUrl'] ?? '',
    duration:    j['duration']    ?? 0,
    year:        j['year']?.toString() ?? '',
    language:    j['language']    ?? '',
    lyricsId:    j['lyricsId']    ?? '',
    hasLyrics:   j['hasLyrics']   ?? false,
    explicit:    j['explicit']    ?? false,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'artists': artists, 'album': album,
    'albumId': albumId, 'image': image, 'streamUrl': streamUrl,
    'downloadUrl': downloadUrl, 'duration': duration, 'year': year,
    'language': language, 'lyricsId': lyricsId, 'hasLyrics': hasLyrics,
    'explicit': explicit,
  };

  String get durationFormatted {
    final m = duration ~/ 60;
    final s = duration % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}

// ── Artist ────────────────────────────────────────────────────────────────────
class Artist {
  final String id, name, image;
  final int followerCount;
  final String dominantLanguage, bio;
  final List<Song> topSongs;
  final List<Album> topAlbums;
  final List<Artist> similarArtists;

  const Artist({
    required this.id, required this.name,
    this.image = '', this.followerCount = 0,
    this.dominantLanguage = '', this.bio = '',
    this.topSongs = const [], this.topAlbums = const [],
    this.similarArtists = const [],
  });

  factory Artist.fromJson(Map<String, dynamic> j) => Artist(
    id:    j['id']   ?? '',
    name:  j['name'] ?? '',
    image: j['image'] ?? '',
    followerCount:     j['followerCount'] ?? 0,
    dominantLanguage:  j['dominantLanguage'] ?? '',
    bio:               j['bio'] ?? '',
    topSongs:    (j['topSongs']      as List? ?? []).map((e) => Song.fromJson(e)).toList(),
    topAlbums:   (j['topAlbums']     as List? ?? []).map((e) => Album.fromJson(e)).toList(),
    similarArtists: (j['similarArtists'] as List? ?? []).map((e) => Artist.fromJson(e)).toList(),
  );
}

// ── Album ─────────────────────────────────────────────────────────────────────
class Album {
  final String id, title, artists, year, image;
  final int songCount;
  final List<Song> songs;

  const Album({
    required this.id, required this.title,
    this.artists = '', this.year = '', this.image = '',
    this.songCount = 0, this.songs = const [],
  });

  factory Album.fromJson(Map<String, dynamic> j) => Album(
    id:        j['id']       ?? '',
    title:     j['title']    ?? j['name'] ?? '',
    artists:   j['artists']  ?? '',
    year:      j['year']?.toString() ?? '',
    image:     j['image']    ?? '',
    songCount: j['songCount'] ?? 0,
    songs:     (j['songs'] as List? ?? []).map((e) => Song.fromJson(e)).toList(),
  );
}

// ── Playlist ──────────────────────────────────────────────────────────────────
class Playlist {
  final String id, name, description, image, ownerId;
  final bool isPublic;
  final List<Song> songs;
  final int songCount, followerCount;

  const Playlist({
    required this.id, required this.name,
    this.description = '', this.image = '', this.ownerId = '',
    this.isPublic = true, this.songs = const [],
    this.songCount = 0, this.followerCount = 0,
  });

  factory Playlist.fromJson(Map<String, dynamic> j) => Playlist(
    id:          j['id']          ?? '',
    name:        j['name']        ?? j['title'] ?? '',
    description: j['description'] ?? '',
    image:       j['image']       ?? '',
    ownerId:     j['ownerId']     ?? '',
    isPublic:    j['isPublic']    ?? true,
    songCount:   j['songCount']   ?? 0,
    followerCount: j['followerCount'] ?? 0,
    songs:       (j['songs'] as List? ?? []).map((e) => Song.fromJson(e)).toList(),
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'description': description, 'image': image,
    'ownerId': ownerId, 'isPublic': isPublic, 'songCount': songCount,
    'followerCount': followerCount,
    'songs': songs.map((s) => s.toJson()).toList(),
  };
}

// ── User ──────────────────────────────────────────────────────────────────────
class UserModel {
  final String id, username, email, displayName, avatar, bio, plan;

  const UserModel({
    required this.id, required this.username, required this.email,
    this.displayName = '', this.avatar = '', this.bio = '', this.plan = 'free',
  });

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
    id:          j['id']          ?? '',
    username:    j['username']    ?? '',
    email:       j['email']       ?? '',
    displayName: j['displayName'] ?? '',
    avatar:      j['avatar']      ?? '',
    bio:         j['bio']         ?? '',
    plan:        j['plan']        ?? 'free',
  );
}
