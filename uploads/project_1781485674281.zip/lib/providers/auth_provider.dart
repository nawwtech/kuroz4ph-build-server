import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  UserModel? _user;
  bool       _loading = false;
  String     _error   = '';

  UserModel? get user    => _user;
  bool       get loading => _loading;
  String     get error   => _error;
  bool       get isLoggedIn => _user != null;

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    final t = p.getString('token');
    if (t == null) return;
    try {
      _user = await ApiService.getProfile();
      notifyListeners();
    } catch (_) {
      await p.remove('token');
    }
  }

  Future<bool> login(String username, String password) async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final res = await ApiService.login(username, password);
      if (res['success'] == true) {
        final p = await SharedPreferences.getInstance();
        await p.setString('token', res['token']);
        _user = UserModel.fromJson(res['user']);
        _loading = false;
        notifyListeners();
        return true;
      }
      _error = res['message'] ?? 'Login failed';
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
    return false;
  }

  Future<bool> register(String username, String email, String password) async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final res = await ApiService.register(username, email, password);
      if (res['success'] == true) {
        final p = await SharedPreferences.getInstance();
        await p.setString('token', res['token']);
        _user = UserModel.fromJson(res['user']);
        _loading = false;
        notifyListeners();
        return true;
      }
      _error = res['message'] ?? 'Register failed';
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
    return false;
  }

  Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('token');
    _user = null;
    notifyListeners();
  }
}
