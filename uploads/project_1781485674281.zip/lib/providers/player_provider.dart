import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import '../models/models.dart';
import 'api_service.dart';

enum RepeatMode { none, all, one }
enum PlayerState { idle, loading, playing, paused, error }

class PlayerProvider extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();

  Song?         _current;
  List<Song>    _queue      = [];
  int           _queueIndex = 0;
  bool          _shuffle    = false;
  RepeatMode    _repeat     = RepeatMode.none;
  PlayerState   _state      = PlayerState.idle;
  Duration      _position   = Duration.zero;
  Duration      _duration   = Duration.zero;
  bool          _showMini   = false;
  String        _lyrics     = '';
  bool          _lyricsLoading = false;

  Song?         get current      => _current;
  List<Song>    get queue        => _queue;
  int           get queueIndex   => _queueIndex;
  bool          get shuffle      => _shuffle;
  RepeatMode    get repeat       => _repeat;
  PlayerState   get state        => _state;
  Duration      get position     => _position;
  Duration      get duration     => _duration;
  bool          get showMini     => _showMini;
  bool          get isPlaying    => _state == PlayerState.playing;
  String        get lyrics       => _lyrics;
  bool          get lyricsLoading => _lyricsLoading;

  double get progress {
    if (_duration.inMilliseconds == 0) return 0;
    return _position.inMilliseconds / _duration.inMilliseconds;
  }

  PlayerProvider() {
    _player.playerStateStream.listen((s) {
      if (s.playing) {
        _state = PlayerState.playing;
      } else if (s.processingState == ProcessingState.loading ||
                 s.processingState == ProcessingState.buffering) {
        _state = PlayerState.loading;
      } else if (s.processingState == ProcessingState.completed) {
        _onComplete();
      } else {
        _state = PlayerState.paused;
      }
      notifyListeners();
    });

    _player.positionStream.listen((p) {
      _position = p;
      notifyListeners();
    });

    _player.durationStream.listen((d) {
      _duration = d ?? Duration.zero;
      notifyListeners();
    });
  }

  Future<void> play(Song song, {List<Song>? queue, int index = 0}) async {
    _current   = song;
    _showMini  = true;
    _state     = PlayerState.loading;
    _lyrics    = '';
    if (queue != null) {
      _queue      = queue;
      _queueIndex = index;
    } else if (!_queue.contains(song)) {
      _queue.insert(_queueIndex + 1, song);
    }
    notifyListeners();

    try {
      await _player.setAudioSource(AudioSource.uri(
        Uri.parse(song.streamUrl),
        tag: MediaItem(
          id:       song.id,
          title:    song.title,
          artist:   song.artists,
          album:    song.album,
          artUri:   song.image.isNotEmpty ? Uri.parse(song.image) : null,
        ),
      ));
      await _player.play();
      ApiService.addHistory(song).catchError((_) {});
      _fetchLyrics(song);
    } catch (e) {
      _state = PlayerState.error;
      notifyListeners();
    }
  }

  Future<void> _fetchLyrics(Song song) async {
    if (!song.hasLyrics) return;
    _lyricsLoading = true;
    notifyListeners();
    try {
      _lyrics = await ApiService.getLyrics(song.id);
    } catch (_) { _lyrics = ''; }
    _lyricsLoading = false;
    notifyListeners();
  }

  Future<void> togglePlay() async {
    if (_player.playing) { await _player.pause(); }
    else { await _player.play(); }
  }

  Future<void> seekTo(Duration pos) => _player.seek(pos);
  Future<void> seekToProgress(double p) => seekTo(_duration * p);

  Future<void> next() async {
    if (_queue.isEmpty) return;
    if (_shuffle) {
      _queueIndex = (0 + (_queue.length * 0.9).toInt()) % _queue.length;
    } else {
      _queueIndex = (_queueIndex + 1) % _queue.length;
    }
    await play(_queue[_queueIndex], queue: _queue, index: _queueIndex);
  }

  Future<void> previous() async {
    if (_position.inSeconds > 3) { await seekTo(Duration.zero); return; }
    if (_queue.isEmpty) return;
    _queueIndex = (_queueIndex - 1 + _queue.length) % _queue.length;
    await play(_queue[_queueIndex], queue: _queue, index: _queueIndex);
  }

  void toggleShuffle() {
    _shuffle = !_shuffle;
    notifyListeners();
  }

  void toggleRepeat() {
    _repeat = RepeatMode.values[(_repeat.index + 1) % RepeatMode.values.length];
    _player.setLoopMode(switch (_repeat) {
      RepeatMode.none => LoopMode.off,
      RepeatMode.all  => LoopMode.all,
      RepeatMode.one  => LoopMode.one,
    });
    notifyListeners();
  }

  void addToQueue(Song song) {
    _queue.add(song);
    notifyListeners();
  }

  void removeFromQueue(int index) {
    _queue.removeAt(index);
    notifyListeners();
  }

  Future<void> _onComplete() async {
    if (_repeat == RepeatMode.one) {
      await _player.seek(Duration.zero);
      await _player.play();
    } else if (_repeat == RepeatMode.all || _queueIndex < _queue.length - 1) {
      await next();
    } else {
      _state = PlayerState.idle;
      notifyListeners();
    }
  }

  void hideMini() { _showMini = false; notifyListeners(); }
  void showMiniPlayer() { _showMini = true; notifyListeners(); }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
