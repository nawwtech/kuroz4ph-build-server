export '../artist/artist_screen.dart';
// AlbumScreen is defined in artist_screen.dart
