import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/models.dart';
import '../../providers/player_provider.dart';
import '../../services/api_service.dart';
import '../../utils/theme.dart';
import '../../widgets/widgets.dart';

// ── Artist Screen ─────────────────────────────────────────────────────────────
class ArtistScreen extends StatefulWidget {
  final String artistId;
  const ArtistScreen({super.key, required this.artistId});
  @override State<ArtistScreen> createState() => _ArtistScreenState();
}

class _ArtistScreenState extends State<ArtistScreen> {
  Artist? _artist;
  bool _loading = true;
  bool _following = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final a = await ApiService.getArtist(widget.artistId);
      final f = await ApiService.checkFollowing(widget.artistId);
      if (mounted) setState(() { _artist = a; _following = f; _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(backgroundColor: kBg, body: const Center(child: CircularProgressIndicator(color: kPrimary)));
    if (_artist == null) return Scaffold(backgroundColor: kBg, appBar: AppBar(), body: const EmptyState(icon: Icons.person_off_rounded, title: 'Not Found', subtitle: ''));

    final a = _artist!;
    return Scaffold(
      backgroundColor: kBg,
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 260, pinned: true,
          backgroundColor: kBg,
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(fit: StackFit.expand, children: [
              if (a.image.isNotEmpty) Image.network(a.image, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: kCard)),
              Container(decoration: BoxDecoration(gradient: LinearGradient(
                colors: [Colors.transparent, kBg], begin: Alignment.topCenter, end: Alignment.bottomCenter,
              ))),
              Positioned(bottom: 20, left: 20, right: 20, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(a.name, style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 30, fontWeight: FontWeight.w900)),
                if (a.followerCount > 0)
                  Text('${_fmt(a.followerCount)} followers', style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 13)),
              ])),
            ]),
          ),
          actions: [
            GestureDetector(
              onTap: () async {
                if (_following) { await ApiService.unfollowItem(a.id); }
                else { await ApiService.followItem({'id': a.id, 'name': a.name, 'image': a.image, 'type': 'artist'}); }
                setState(() => _following = !_following);
              },
              child: Container(
                margin: const EdgeInsets.only(right: 16),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: _following ? kCard : kPrimary,
                  borderRadius: BorderRadius.circular(20),
                  border: _following ? Border.all(color: kBorder) : null,
                ),
                child: Text(_following ? 'Following' : 'Follow',
                  style: const TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
        if (a.topSongs.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionHeader(title: 'Popular Songs')),
          SliverList(delegate: SliverChildBuilderDelegate((_, i) => SongTile(
            song: a.topSongs[i], showIndex: true, index: i,
            onTap: () => context.read<PlayerProvider>().play(a.topSongs[i], queue: a.topSongs, index: i),
          ), childCount: a.topSongs.take(10).length)),
        ],
        if (a.topAlbums.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionHeader(title: 'Albums')),
          SliverToBoxAdapter(child: SizedBox(
            height: 190,
            child: ListView.builder(
              scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: a.topAlbums.length,
              itemBuilder: (_, i) => AlbumCard(
                title: a.topAlbums[i].title, subtitle: a.topAlbums[i].year,
                image: a.topAlbums[i].image,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AlbumScreen(albumId: a.topAlbums[i].id))),
              ),
            ),
          )),
        ],
        if (a.similarArtists.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionHeader(title: 'Similar Artists')),
          SliverToBoxAdapter(child: SizedBox(
            height: 130,
            child: ListView.builder(
              scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: a.similarArtists.length,
              itemBuilder: (_, i) => ArtistCard(
                artist: a.similarArtists[i],
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ArtistScreen(artistId: a.similarArtists[i].id))),
              ),
            ),
          )),
        ],
        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ]),
    );
  }

  String _fmt(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}

// ── Album Screen ──────────────────────────────────────────────────────────────
class AlbumScreen extends StatefulWidget {
  final String albumId;
  const AlbumScreen({super.key, required this.albumId});
  @override State<AlbumScreen> createState() => _AlbumScreenState();
}

class _AlbumScreenState extends State<AlbumScreen> {
  Album? _album;
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final a = await ApiService.getAlbum(widget.albumId);
      if (mounted) setState(() { _album = a; _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(backgroundColor: kBg, body: const Center(child: CircularProgressIndicator(color: kPrimary)));
    if (_album == null) return Scaffold(backgroundColor: kBg, appBar: AppBar(), body: const EmptyState(icon: Icons.album_rounded, title: 'Not Found', subtitle: ''));

    final a = _album!;
    return Scaffold(
      backgroundColor: kBg,
      body: CustomScrollView(slivers: [
        SliverAppBar(expandedHeight: 300, pinned: true, backgroundColor: kBg,
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(fit: StackFit.expand, children: [
              if (a.image.isNotEmpty) ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: Image.network(a.image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: kCard)),
              ),
              Container(color: Colors.black.withOpacity(0.55)),
              Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const SizedBox(height: 40),
                KImage(a.image, width: 180, height: 180, radius: 16),
              ])),
              Positioned(bottom: 20, left: 20, right: 20, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(a.title, style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 24, fontWeight: FontWeight.w900)),
                Text('${a.artists} • ${a.year} • ${a.songs.length} songs',
                  style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12)),
              ])),
            ]),
          ),
          actions: [
            if (a.songs.isNotEmpty)
              Padding(padding: const EdgeInsets.only(right: 12), child: GestureDetector(
                onTap: () => context.read<PlayerProvider>().play(a.songs.first, queue: a.songs, index: 0),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: kPrimary, shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: kPrimary.withOpacity(0.5), blurRadius: 12)]),
                  child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 24),
                ),
              )),
          ],
        ),
        SliverList(delegate: SliverChildBuilderDelegate((_, i) => SongTile(
          song: a.songs[i], showIndex: true, index: i,
          onTap: () => context.read<PlayerProvider>().play(a.songs[i], queue: a.songs, index: i),
          onMore: () => showSongOptions(context, a.songs[i]),
        ), childCount: a.songs.length)),
        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ]),
    );
  }
}
