import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../utils/theme.dart';
import '../main_screen.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure    = true;

  Future<void> _login() async {
    final ok = await context.read<AuthProvider>().login(_userCtrl.text.trim(), _passCtrl.text);
    if (!mounted) return;
    if (ok) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainScreen()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(context.read<AuthProvider>().error, style: const TextStyle(fontFamily: kFont)),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              // Logo
              Center(
                child: Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    gradient: const LinearGradient(colors: [kPrimary, kPrimary2]),
                    boxShadow: [BoxShadow(color: kPrimary.withOpacity(0.4), blurRadius: 24)],
                  ),
                  child: const Icon(Icons.music_note_rounded, color: Colors.white, size: 44),
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: RichText(
                  text: const TextSpan(
                    style: TextStyle(fontFamily: kFont, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 2),
                    children: [
                      TextSpan(text: 'KU', style: TextStyle(color: kPrimary)),
                      TextSpan(text: 'RO', style: TextStyle(color: Colors.white)),
                      TextSpan(text: 'FY', style: TextStyle(color: kPrimary2)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Center(child: Text('Music for your soul', style: TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 13, letterSpacing: 1.5))),
              const SizedBox(height: 50),

              Text('Welcome Back', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 6),
              Text('Sign in to continue listening', style: TextStyle(color: kTextSub, fontFamily: kFont)),
              const SizedBox(height: 32),

              // Username
              _label('Username or Email'),
              const SizedBox(height: 8),
              _input(_userCtrl, 'Enter your username', Icons.person_rounded),
              const SizedBox(height: 18),

              // Password
              _label('Password'),
              const SizedBox(height: 8),
              _input(_passCtrl, 'Enter your password', Icons.lock_rounded, obscure: _obscure, suffix: IconButton(
                icon: Icon(_obscure ? Icons.visibility_rounded : Icons.visibility_off_rounded, color: kTextMuted, size: 20),
                onPressed: () => setState(() => _obscure = !_obscure),
              )),
              const SizedBox(height: 32),

              // Login button
              _btn(auth.loading ? null : _login, auth.loading, 'LOGIN'),
              const SizedBox(height: 20),

              // Register
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Don't have an account? ", style: TextStyle(color: kTextSub, fontFamily: kFont)),
                  GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen())),
                    child: const Text('Sign Up', style: TextStyle(color: kPrimary, fontFamily: kFont, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),

              const SizedBox(height: 40),
              Center(child: Text('Developer: @kuroz4ph', style: TextStyle(color: kTextMuted, fontSize: 11, fontFamily: kFont))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _label(String t) => Text(t, style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 13, fontWeight: FontWeight.w600));

  Widget _input(TextEditingController c, String hint, IconData icon, {bool obscure = false, Widget? suffix}) {
    return Container(
      decoration: BoxDecoration(
        color: kCardLight, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder),
      ),
      child: TextField(
        controller: c, obscureText: obscure,
        style: const TextStyle(color: kText, fontFamily: kFont, fontSize: 15),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: kTextMuted, fontFamily: kFont),
          prefixIcon: Icon(icon, color: kTextMuted, size: 20),
          suffixIcon: suffix,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }

  Widget _btn(VoidCallback? onTap, bool loading, String label) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity, height: 54,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: loading ? [kBorder, kBorder] : [kPrimary, kPrimary2],
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: loading ? [] : [BoxShadow(color: kPrimary.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 6))],
        ),
        child: Center(
          child: loading
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : Text(label, style: const TextStyle(fontFamily: kFont, color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2)),
        ),
      ),
    );
  }
}
