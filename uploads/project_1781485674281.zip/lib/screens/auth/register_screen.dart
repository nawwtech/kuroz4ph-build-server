import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../utils/theme.dart';
import '../main_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _userCtrl  = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl  = TextEditingController();
  final _confCtrl  = TextEditingController();
  bool _obscure = true;

  Future<void> _register() async {
    if (_passCtrl.text != _confCtrl.text) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Passwords do not match', style: TextStyle(fontFamily: kFont)),
        backgroundColor: Colors.red,
      ));
      return;
    }
    final ok = await context.read<AuthProvider>().register(
      _userCtrl.text.trim(), _emailCtrl.text.trim(), _passCtrl.text,
    );
    if (!mounted) return;
    if (ok) {
      Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (_) => const MainScreen()), (_) => false);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(context.read<AuthProvider>().error, style: const TextStyle(fontFamily: kFont)),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg, elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: kText),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(28, 12, 28, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Create Account', style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 6),
              Text('Join Kurofy and start listening', style: TextStyle(color: kTextSub, fontFamily: kFont)),
              const SizedBox(height: 32),
              _label('Username'),
              const SizedBox(height: 8),
              _input(_userCtrl, 'Choose a username', Icons.person_rounded),
              const SizedBox(height: 16),
              _label('Email'),
              const SizedBox(height: 8),
              _input(_emailCtrl, 'Enter your email', Icons.email_rounded),
              const SizedBox(height: 16),
              _label('Password'),
              const SizedBox(height: 8),
              _input(_passCtrl, 'Create a password', Icons.lock_rounded, obscure: _obscure, suffix: IconButton(
                icon: Icon(_obscure ? Icons.visibility_rounded : Icons.visibility_off_rounded, color: kTextMuted, size: 20),
                onPressed: () => setState(() => _obscure = !_obscure),
              )),
              const SizedBox(height: 16),
              _label('Confirm Password'),
              const SizedBox(height: 8),
              _input(_confCtrl, 'Repeat your password', Icons.lock_outlined),
              const SizedBox(height: 32),
              _btn(auth.loading ? null : _register, auth.loading, 'CREATE ACCOUNT'),
              const SizedBox(height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('Already have an account? ', style: TextStyle(color: kTextSub, fontFamily: kFont)),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: const Text('Sign In', style: TextStyle(color: kPrimary, fontFamily: kFont, fontWeight: FontWeight.bold)),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _label(String t) => Text(t, style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 13, fontWeight: FontWeight.w600));

  Widget _input(TextEditingController c, String hint, IconData icon, {bool obscure = false, Widget? suffix}) {
    return Container(
      decoration: BoxDecoration(color: kCardLight, borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder)),
      child: TextField(
        controller: c, obscureText: obscure,
        style: const TextStyle(color: kText, fontFamily: kFont, fontSize: 15),
        decoration: InputDecoration(
          hintText: hint, hintStyle: const TextStyle(color: kTextMuted, fontFamily: kFont),
          prefixIcon: Icon(icon, color: kTextMuted, size: 20), suffixIcon: suffix,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }

  Widget _btn(VoidCallback? onTap, bool loading, String label) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity, height: 54,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: loading ? [kBorder, kBorder] : [kPrimary, kPrimary2]),
          borderRadius: BorderRadius.circular(14),
          boxShadow: loading ? [] : [BoxShadow(color: kPrimary.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 6))],
        ),
        child: Center(child: loading
          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
          : Text(label, style: const TextStyle(fontFamily: kFont, color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2))),
      ),
    );
  }
}
