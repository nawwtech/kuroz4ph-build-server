import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../utils/theme.dart';
import '../main_screen.dart';
import 'login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade, _scale;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _fade  = CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.6, curve: Curves.easeOut));
    _scale = Tween<double>(begin: 0.8, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut));
    _ctrl.forward();
    _navigate();
  }

  Future<void> _navigate() async {
    await Future.delayed(const Duration(milliseconds: 2000));
    if (!mounted) return;
    final auth = context.read<AuthProvider>();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => auth.isLoggedIn ? const MainScreen() : const LoginScreen()),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: ScaleTransition(
            scale: _scale,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Logo
                Container(
                  width: 100, height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: const LinearGradient(
                      colors: [kPrimary, kPrimary2],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(color: kPrimary.withOpacity(0.5), blurRadius: 30, spreadRadius: 2),
                    ],
                  ),
                  child: const Icon(Icons.music_note_rounded, color: Colors.white, size: 52),
                ),
                const SizedBox(height: 24),
                RichText(
                  text: const TextSpan(
                    style: TextStyle(fontFamily: kFont, fontSize: 42, fontWeight: FontWeight.w900, letterSpacing: 2),
                    children: [
                      TextSpan(text: 'KU', style: TextStyle(color: kPrimary)),
                      TextSpan(text: 'RO', style: TextStyle(color: Colors.white)),
                      TextSpan(text: 'FY', style: TextStyle(color: kPrimary2)),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Text('Music for your soul', style: TextStyle(
                  fontFamily: kFont, color: kTextSub, fontSize: 14, letterSpacing: 1.5,
                )),
                const SizedBox(height: 60),
                SizedBox(
                  width: 24, height: 24,
                  child: CircularProgressIndicator(
                    color: kPrimary, strokeWidth: 2.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
