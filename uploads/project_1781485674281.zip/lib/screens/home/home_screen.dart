import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/models.dart';
import '../../providers/auth_provider.dart';
import '../../providers/player_provider.dart';
import '../../services/api_service.dart';
import '../../utils/theme.dart';
import '../../widgets/widgets.dart';
import '../artist/artist_screen.dart';
import '../album/album_screen.dart';
import '../playlist/playlist_detail_screen.dart';
import '../search/search_screen.dart';
import '../player/full_player_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, dynamic> _home = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      _home = await ApiService.getHome();
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  void _playSong(Song song, List<Song> queue, int index) {
    context.read<PlayerProvider>().play(song, queue: queue, index: index);
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    final hour = DateTime.now().hour;
    final greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

    return Scaffold(
      backgroundColor: kBg,
      body: RefreshIndicator(
        color: kPrimary, backgroundColor: kCard,
        onRefresh: _load,
        child: CustomScrollView(
          slivers: [
            // App bar
            SliverAppBar(
              floating: true, snap: true,
              backgroundColor: kBg, elevation: 0,
              expandedHeight: 90,
              flexibleSpace: FlexibleSpaceBar(
                background: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 50, 20, 0),
                  child: Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(greeting, style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 13)),
                      Text(user?.displayName ?? user?.username ?? 'Listener',
                        style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 22, fontWeight: FontWeight.w900)),
                    ])),
                    GestureDetector(
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen())),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(color: kCardLight, borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
                        child: const Icon(Icons.search_rounded, color: kText, size: 22),
                      ),
                    ),
                  ]),
                ),
              ),
            ),

            if (_loading)
              SliverToBoxAdapter(child: Column(children: List.generate(3, (_) => const SongTileSkeleton())))
            else ...[
              // Trending
              if ((_home['trending'] as List?)?.isNotEmpty == true) ...[
                const SliverToBoxAdapter(child: SectionHeader(title: '🔥 Trending Now')),
                SliverToBoxAdapter(child: _buildTrendingList()),
              ],

              // Top Artists
              if ((_home['topArtists'] as List?)?.isNotEmpty == true) ...[
                const SliverToBoxAdapter(child: SectionHeader(title: '🎤 Top Artists')),
                SliverToBoxAdapter(child: _buildArtists()),
              ],

              // New Releases
              if ((_home['newReleases'] as List?)?.isNotEmpty == true) ...[
                const SliverToBoxAdapter(child: SectionHeader(title: '🆕 New Releases')),
                SliverToBoxAdapter(child: _buildAlbums()),
              ],

              // Top Charts
              if ((_home['topCharts'] as List?)?.isNotEmpty == true) ...[
                const SliverToBoxAdapter(child: SectionHeader(title: '📊 Top Charts')),
                SliverToBoxAdapter(child: _buildCharts()),
              ],

              // Top Playlists
              if ((_home['topPlaylists'] as List?)?.isNotEmpty == true) ...[
                const SliverToBoxAdapter(child: SectionHeader(title: '🎧 Featured Playlists')),
                SliverToBoxAdapter(child: _buildPlaylists()),
              ],

              const SliverToBoxAdapter(child: SizedBox(height: 120)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTrendingList() {
    final songs = (_home['trending'] as List? ?? []).map((e) => Song.fromJson(e as Map<String, dynamic>)).toList();
    return SizedBox(
      height: 220,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: songs.length,
        itemBuilder: (_, i) {
          final s = songs[i];
          return GestureDetector(
            onTap: () => _playSong(s, songs, i),
            child: Container(
              width: 160, margin: const EdgeInsets.only(right: 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Stack(children: [
                  KImage(s.image, width: 160, height: 160, radius: 14),
                  Positioned(
                    bottom: 8, right: 8,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: kPrimary, borderRadius: BorderRadius.circular(12),
                        boxShadow: [BoxShadow(color: kPrimary.withOpacity(0.5), blurRadius: 10)],
                      ),
                      child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 18),
                    ),
                  ),
                  Positioned(
                    top: 8, left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7), borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text('#${i + 1}', style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 11, fontWeight: FontWeight.w900)),
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 13)),
                Text(s.artists, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 11)),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _buildArtists() {
    final artists = (_home['topArtists'] as List? ?? []).map((e) => Artist.fromJson(e as Map<String, dynamic>)).toList();
    return SizedBox(
      height: 130,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: artists.length,
        itemBuilder: (_, i) => ArtistCard(
          artist: artists[i],
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ArtistScreen(artistId: artists[i].id))),
        ),
      ),
    );
  }

  Widget _buildAlbums() {
    final albums = (_home['newReleases'] as List? ?? []).map((e) => Album.fromJson(e as Map<String, dynamic>)).toList();
    return SizedBox(
      height: 190,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: albums.length,
        itemBuilder: (_, i) => AlbumCard(
          title: albums[i].title, subtitle: albums[i].artists,
          image: albums[i].image,
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AlbumScreen(albumId: albums[i].id))),
        ),
      ),
    );
  }

  Widget _buildCharts() {
    final charts = (_home['topCharts'] as List? ?? []).map((e) => Playlist.fromJson(e as Map<String, dynamic>)).toList();
    return SizedBox(
      height: 190,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: charts.length,
        itemBuilder: (_, i) => AlbumCard(
          title: charts[i].name, subtitle: '${charts[i].songCount} songs',
          image: charts[i].image,
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlaylistDetailScreen(playlist: charts[i], isSaavn: true))),
        ),
      ),
    );
  }

  Widget _buildPlaylists() {
    final playlists = (_home['topPlaylists'] as List? ?? []).map((e) => Playlist.fromJson(e as Map<String, dynamic>)).toList();
    return SizedBox(
      height: 190,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: playlists.length,
        itemBuilder: (_, i) => AlbumCard(
          title: playlists[i].name, subtitle: '${playlists[i].songCount} songs',
          image: playlists[i].image,
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlaylistDetailScreen(playlist: playlists[i], isSaavn: true))),
        ),
      ),
    );
  }
}
