import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/models.dart';
import '../../providers/player_provider.dart';
import '../../services/api_service.dart';
import '../../utils/theme.dart';
import '../../widgets/widgets.dart';
import '../playlist/playlist_detail_screen.dart';
import '../playlist/create_playlist_screen.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  List<Song>     _liked     = [];
  List<Song>     _history   = [];
  List<Playlist> _playlists = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    _load();
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([
        ApiService.getLiked(), ApiService.getHistory(), ApiService.getMyPlaylists(),
      ]);
      if (mounted) setState(() {
        _liked     = results[0] as List<Song>;
        _history   = results[1] as List<Song>;
        _playlists = results[2] as List<Playlist>;
        _loading   = false;
      });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg, elevation: 0, automaticallyImplyLeading: false,
        title: const Text('Your Library', style: TextStyle(fontFamily: kFont, fontWeight: FontWeight.w900, fontSize: 22)),
        actions: [
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: kPrimary, borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.add_rounded, color: Colors.white, size: 18),
            ),
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreatePlaylistScreen()));
              _load();
            },
          ),
          const SizedBox(width: 8),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: kPrimary, labelColor: kPrimary, unselectedLabelColor: kTextSub,
          labelStyle: const TextStyle(fontFamily: kFont, fontWeight: FontWeight.w700, fontSize: 12),
          tabs: const [Tab(text: 'PLAYLISTS'), Tab(text: 'LIKED'), Tab(text: 'HISTORY')],
        ),
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: kPrimary))
        : TabBarView(controller: _tabCtrl, children: [
            _buildPlaylists(), _buildLiked(), _buildHistory(),
          ]),
    );
  }

  Widget _buildPlaylists() {
    if (_playlists.isEmpty) {
      return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const EmptyState(icon: Icons.queue_music_rounded, title: 'No Playlists', subtitle: 'Create your first playlist'),
        const SizedBox(height: 16),
        GestureDetector(
          onTap: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreatePlaylistScreen()));
            _load();
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [kPrimary, kPrimary2]), borderRadius: BorderRadius.circular(14)),
            child: const Text('Create Playlist', style: TextStyle(fontFamily: kFont, color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
          ),
        ),
      ]);
    }
    return RefreshIndicator(color: kPrimary, backgroundColor: kCard, onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.only(bottom: 100),
        itemCount: _playlists.length,
        itemBuilder: (_, i) {
          final p = _playlists[i];
          return ListTile(
            leading: KImage(p.image.isNotEmpty ? p.image : '', width: 52, height: 52, radius: 10),
            title: Text(p.name, style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 14)),
            subtitle: Text('${p.songs.length} songs • ${p.isPublic ? "Public" : "Private"}',
              style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12)),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlaylistDetailScreen(playlist: p))),
            trailing: const Icon(Icons.chevron_right_rounded, color: kTextMuted),
          );
        },
      ),
    );
  }

  Widget _buildLiked() {
    if (_liked.isEmpty) return const EmptyState(icon: Icons.favorite_rounded, title: 'No Liked Songs', subtitle: 'Like songs to find them here');
    return RefreshIndicator(color: kPrimary, backgroundColor: kCard, onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.only(bottom: 100),
        itemCount: _liked.length,
        itemBuilder: (_, i) => SongTile(
          song: _liked[i],
          onTap: () => context.read<PlayerProvider>().play(_liked[i], queue: _liked, index: i),
          onMore: () => showSongOptions(context, _liked[i]),
        ),
      ),
    );
  }

  Widget _buildHistory() {
    if (_history.isEmpty) return const EmptyState(icon: Icons.history_rounded, title: 'No History', subtitle: 'Songs you play will appear here');
    return RefreshIndicator(color: kPrimary, backgroundColor: kCard, onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.only(bottom: 100),
        itemCount: _history.length,
        itemBuilder: (_, i) => SongTile(
          song: _history[i],
          onTap: () => context.read<PlayerProvider>().play(_history[i], queue: _history, index: i),
          onMore: () => showSongOptions(context, _history[i]),
        ),
      ),
    );
  }
}
