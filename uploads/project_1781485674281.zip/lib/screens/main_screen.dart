import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/player_provider.dart';
import '../utils/theme.dart';
import '../widgets/mini_player.dart';
import 'home/home_screen.dart';
import 'search/search_screen.dart';
import 'library/library_screen.dart';
import 'profile/profile_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _idx = 0;

  final _screens = const [
    HomeScreen(),
    SearchScreen(),
    LibraryScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();

    return Scaffold(
      backgroundColor: kBg,
      body: IndexedStack(index: _idx, children: _screens),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Mini player
          if (player.showMini && player.current != null)
            const MiniPlayer(),

          // Nav bar
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0E0E18),
              border: Border(top: BorderSide(color: kBorder.withOpacity(0.5))),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, -2))],
            ),
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _navItem(0, Icons.space_dashboard_rounded, Icons.space_dashboard_outlined, 'Home'),
                    _navItem(1, Icons.search_rounded, Icons.search_rounded, 'Search'),
                    _navItem(2, Icons.library_music_rounded, Icons.library_music_outlined, 'Library'),
                    _navItem(3, Icons.person_rounded, Icons.person_outline_rounded, 'Profile'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navItem(int index, IconData active, IconData inactive, String label) {
    final isActive = _idx == index;
    return GestureDetector(
      onTap: () => setState(() => _idx = index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? kPrimary.withOpacity(0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 180),
            child: Icon(
              isActive ? active : inactive,
              color: isActive ? kPrimary : kTextMuted,
              size: 24, key: ValueKey(isActive),
            ),
          ),
          const SizedBox(height: 3),
          Text(label, style: TextStyle(
            fontFamily: kFont, fontSize: 10, fontWeight: isActive ? FontWeight.w800 : FontWeight.w500,
            color: isActive ? kPrimary : kTextMuted, letterSpacing: 0.3,
          )),
        ]),
      ),
    );
  }
}
