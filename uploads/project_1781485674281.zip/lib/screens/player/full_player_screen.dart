import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/player_provider.dart';
import '../../utils/theme.dart';
import '../../widgets/widgets.dart';
import '../../services/api_service.dart';

class FullPlayerScreen extends StatefulWidget {
  const FullPlayerScreen({super.key});
  @override
  State<FullPlayerScreen> createState() => _FullPlayerScreenState();
}

class _FullPlayerScreenState extends State<FullPlayerScreen> with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  bool _isLiked = false;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkLiked());
  }

  Future<void> _checkLiked() async {
    final song = context.read<PlayerProvider>().current;
    if (song == null) return;
    try {
      final liked = await ApiService.checkLiked(song.id);
      if (mounted) setState(() => _isLiked = liked);
    } catch (_) {}
  }

  Future<void> _toggleLike() async {
    final song = context.read<PlayerProvider>().current;
    if (song == null) return;
    try {
      if (_isLiked) {
        await ApiService.unlikeSong(song.id);
      } else {
        await ApiService.likeSong(song);
      }
      setState(() => _isLiked = !_isLiked);
    } catch (_) {}
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final song   = player.current;
    if (song == null) return const Scaffold(backgroundColor: kBg);

    return Scaffold(
      body: Stack(fit: StackFit.expand, children: [
        // Blurred background
        if (song.image.isNotEmpty)
          ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
            child: Image.network(song.image, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: kCard),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.75)),

        SafeArea(
          child: Column(children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 0),
              child: Row(children: [
                IconButton(
                  icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32, color: kText),
                  onPressed: () => Navigator.pop(context),
                ),
                Expanded(child: Column(children: [
                  const Text('NOW PLAYING', style: TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.w700)),
                  Text(song.album.isNotEmpty ? song.album : 'Single', maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 14, fontWeight: FontWeight.w700)),
                ])),
                IconButton(
                  icon: const Icon(Icons.more_vert_rounded, color: kText, size: 24),
                  onPressed: () => showSongOptions(context, song, isLiked: _isLiked, onLike: _toggleLike),
                ),
              ]),
            ),

            // Tabs
            TabBar(
              controller: _tabCtrl,
              indicatorColor: kPrimary,
              indicatorSize: TabBarIndicatorSize.label,
              labelStyle: const TextStyle(fontFamily: kFont, fontWeight: FontWeight.w700, fontSize: 13),
              unselectedLabelColor: kTextSub,
              labelColor: kPrimary,
              tabs: const [Tab(text: 'PLAYER'), Tab(text: 'LYRICS'), Tab(text: 'QUEUE')],
            ),

            Expanded(child: TabBarView(controller: _tabCtrl, children: [
              _buildPlayerTab(context, player, song),
              _buildLyricsTab(player),
              _buildQueueTab(context, player),
            ])),
          ]),
        ),
      ]),
    );
  }

  Widget _buildPlayerTab(BuildContext context, PlayerProvider player, song) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(children: [
        const SizedBox(height: 20),
        // Cover
        Hero(
          tag: 'player_cover',
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(color: kPrimary.withOpacity(0.3), blurRadius: 40, spreadRadius: 4, offset: const Offset(0, 10))],
            ),
            child: KImage(song.image, width: 300, height: 300, radius: 24),
          ),
        ),
        const SizedBox(height: 28),

        // Song info + like
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(song.title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w900, fontSize: 22)),
            const SizedBox(height: 4),
            Text(song.artists, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 14)),
          ])),
          GestureDetector(
            onTap: _toggleLike,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: Icon(
                _isLiked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: _isLiked ? Colors.red : kTextSub, size: 28,
                key: ValueKey(_isLiked),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 24),

        // Progress
        SliderTheme(
          data: SliderThemeData(
            thumbColor: Colors.white,
            activeTrackColor: kPrimary,
            inactiveTrackColor: Colors.white.withOpacity(0.2),
            trackHeight: 3.5,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 18),
          ),
          child: Slider(
            value: player.progress.clamp(0.0, 1.0),
            onChanged: (v) => player.seekToProgress(v),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(_fmt(player.position), style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12)),
            Text(_fmt(player.duration), style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 16),

        // Controls
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _iconBtn(
            player.shuffle ? Icons.shuffle_on_rounded : Icons.shuffle_rounded,
            color: player.shuffle ? kPrimary : kTextSub,
            onTap: () => player.toggleShuffle(), size: 26,
          ),
          _iconBtn(Icons.skip_previous_rounded, onTap: () => player.previous(), size: 36),
          GestureDetector(
            onTap: () => player.togglePlay(),
            child: Container(
              width: 66, height: 66,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [kPrimary, kPrimary2]),
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: kPrimary.withOpacity(0.5), blurRadius: 20, spreadRadius: 2)],
              ),
              child: player.state == PlayerState.loading
                ? const Padding(padding: EdgeInsets.all(18), child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                : Icon(player.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 38),
            ),
          ),
          _iconBtn(Icons.skip_next_rounded, onTap: () => player.next(), size: 36),
          _iconBtn(
            switch (player.repeat) {
              RepeatMode.none => Icons.repeat_rounded,
              RepeatMode.all  => Icons.repeat_on_rounded,
              RepeatMode.one  => Icons.repeat_one_on_rounded,
            },
            color: player.repeat != RepeatMode.none ? kPrimary : kTextSub,
            onTap: () => player.toggleRepeat(), size: 26,
          ),
        ]),
      ]),
    );
  }

  Widget _buildLyricsTab(PlayerProvider player) {
    if (player.lyricsLoading) {
      return const Center(child: CircularProgressIndicator(color: kPrimary));
    }
    if (player.lyrics.isEmpty) {
      return const EmptyState(icon: Icons.lyrics_rounded, title: 'No Lyrics', subtitle: 'Lyrics not available for this song');
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Text(player.lyrics, style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 16, height: 2.0)),
    );
  }

  Widget _buildQueueTab(BuildContext context, PlayerProvider player) {
    if (player.queue.isEmpty) {
      return const EmptyState(icon: Icons.queue_music_rounded, title: 'Queue Empty', subtitle: 'Add songs to the queue');
    }
    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 100),
      itemCount: player.queue.length,
      itemBuilder: (_, i) {
        final s = player.queue[i];
        return SongTile(
          song: s, isPlaying: i == player.queueIndex,
          onTap: () => player.play(s, queue: player.queue, index: i),
          onMore: () => player.removeFromQueue(i),
        );
      },
    );
  }

  Widget _iconBtn(IconData icon, {required VoidCallback onTap, Color color = kText, double size = 28}) {
    return GestureDetector(onTap: onTap, child: Icon(icon, color: color, size: size));
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}
