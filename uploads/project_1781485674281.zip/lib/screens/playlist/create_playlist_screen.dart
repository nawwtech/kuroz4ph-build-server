import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../../utils/theme.dart';

class CreatePlaylistScreen extends StatefulWidget {
  const CreatePlaylistScreen({super.key});
  @override State<CreatePlaylistScreen> createState() => _CreatePlaylistScreenState();
}

class _CreatePlaylistScreenState extends State<CreatePlaylistScreen> {
  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  bool _isPublic = true;
  bool _loading  = false;

  Future<void> _create() async {
    if (_nameCtrl.text.trim().isEmpty) return;
    setState(() => _loading = true);
    try {
      await ApiService.createPlaylist(_nameCtrl.text.trim(), desc: _descCtrl.text.trim(), isPublic: _isPublic);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString(), style: const TextStyle(fontFamily: kFont)), backgroundColor: Colors.red));
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg, elevation: 0,
        title: const Text('New Playlist', style: TextStyle(fontFamily: kFont, fontWeight: FontWeight.w900, fontSize: 18)),
        actions: [
          TextButton(
            onPressed: _loading ? null : _create,
            child: _loading
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: kPrimary, strokeWidth: 2))
              : const Text('Create', style: TextStyle(fontFamily: kFont, color: kPrimary, fontWeight: FontWeight.w800, fontSize: 15)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          // Playlist cover placeholder
          Center(child: Container(
            width: 140, height: 140,
            decoration: BoxDecoration(
              color: kCardLight, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kBorder),
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.music_note_rounded, color: kPrimary, size: 44),
              const SizedBox(height: 8),
              Text('Playlist Cover', style: TextStyle(fontFamily: kFont, color: kTextMuted, fontSize: 11)),
            ]),
          )),
          const SizedBox(height: 28),

          // Name
          _field(_nameCtrl, 'Playlist Name', 'My Playlist'),
          const SizedBox(height: 16),
          _field(_descCtrl, 'Description (optional)', 'Add a description...', maxLines: 3),
          const SizedBox(height: 20),

          // Public toggle
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder)),
            child: SwitchListTile(
              title: const Text('Public Playlist', style: TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 14)),
              subtitle: Text(_isPublic ? 'Anyone can see this playlist' : 'Only you can see this',
                style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12)),
              value: _isPublic,
              activeColor: kPrimary,
              onChanged: (v) => setState(() => _isPublic = v),
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ]),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, String hint, {int maxLines = 1}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      Container(
        decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
        child: TextField(
          controller: c, maxLines: maxLines,
          style: const TextStyle(color: kText, fontFamily: kFont, fontSize: 15),
          decoration: InputDecoration(
            hintText: hint, hintStyle: const TextStyle(color: kTextMuted, fontFamily: kFont),
            border: InputBorder.none, contentPadding: const EdgeInsets.all(14),
          ),
        ),
      ),
    ]);
  }
}
