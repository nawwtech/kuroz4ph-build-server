import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/models.dart';
import '../../providers/player_provider.dart';
import '../../services/api_service.dart';
import '../../utils/theme.dart';
import '../../widgets/widgets.dart';

// ── Playlist Detail ───────────────────────────────────────────────────────────
class PlaylistDetailScreen extends StatefulWidget {
  final Playlist playlist;
  final bool isSaavn;
  const PlaylistDetailScreen({super.key, required this.playlist, this.isSaavn = false});
  @override State<PlaylistDetailScreen> createState() => _PlaylistDetailScreenState();
}

class _PlaylistDetailScreenState extends State<PlaylistDetailScreen> {
  Playlist? _playlist;
  bool _loading = true;
  bool _following = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      Playlist? pl;
      if (widget.isSaavn) {
        pl = await ApiService.getSaavnPlaylist(widget.playlist.id);
      } else {
        pl = await ApiService.getPlaylist(widget.playlist.id);
      }
      if (mounted) setState(() { _playlist = pl ?? widget.playlist; _loading = false; });
    } catch (_) {
      if (mounted) setState(() { _playlist = widget.playlist; _loading = false; });
    }
  }

  void _playAll() {
    final songs = _playlist?.songs ?? [];
    if (songs.isEmpty) return;
    context.read<PlayerProvider>().play(songs.first, queue: songs, index: 0);
  }

  void _shuffle() {
    final songs = List<Song>.from(_playlist?.songs ?? [])..shuffle();
    if (songs.isEmpty) return;
    context.read<PlayerProvider>()
      ..toggleShuffle()
      ..play(songs.first, queue: songs, index: 0);
  }

  @override
  Widget build(BuildContext context) {
    final pl = _playlist ?? widget.playlist;

    return Scaffold(
      backgroundColor: kBg,
      body: CustomScrollView(
        slivers: [
          // ── App Bar ──────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 320, pinned: true, backgroundColor: kBg,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(fit: StackFit.expand, children: [
                if (pl.image.isNotEmpty)
                  ImageFiltered(
                    imageFilter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                    child: Image.network(pl.image, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(color: kCard)),
                  ),
                Container(color: Colors.black.withOpacity(0.6)),
                Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const SizedBox(height: 50),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 30, offset: const Offset(0, 10))],
                    ),
                    child: KImage(pl.image, width: 170, height: 170, radius: 16),
                  ),
                ])),
                Positioned(
                  bottom: 20, left: 20, right: 20,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(pl.name, style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 22, fontWeight: FontWeight.w900),
                      maxLines: 2, overflow: TextOverflow.ellipsis),
                    if (pl.description.isNotEmpty)
                      Text(pl.description, style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12), maxLines: 1),
                    Text('${pl.songs.length} songs', style: const TextStyle(fontFamily: kFont, color: kTextMuted, fontSize: 12)),
                  ]),
                ),
              ]),
            ),
          ),

          // ── Action buttons ───────────────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Row(children: [
                Expanded(child: GestureDetector(
                  onTap: _playAll,
                  child: Container(
                    height: 46,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [kPrimary, kPrimary2]),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: kPrimary.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4))],
                    ),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.play_arrow_rounded, color: Colors.white, size: 22),
                      SizedBox(width: 6),
                      Text('Play All', style: TextStyle(fontFamily: kFont, color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
                    ]),
                  ),
                )),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: _shuffle,
                  child: Container(
                    height: 46, width: 46,
                    decoration: BoxDecoration(color: kCardLight, borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
                    child: const Icon(Icons.shuffle_rounded, color: kPrimary, size: 22),
                  ),
                ),
                const SizedBox(width: 8),
                if (!widget.isSaavn)
                  GestureDetector(
                    onTap: () async {
                      final confirmed = await showDialog<bool>(
                        context: context,
                        builder: (_) => AlertDialog(
                          backgroundColor: kCard,
                          title: const Text('Delete Playlist', style: TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.bold)),
                          content: const Text('Are you sure?', style: TextStyle(fontFamily: kFont, color: kTextSub)),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel', style: TextStyle(fontFamily: kFont, color: kTextSub))),
                            TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete', style: TextStyle(fontFamily: kFont, color: Colors.red, fontWeight: FontWeight.bold))),
                          ],
                        ),
                      );
                      if (confirmed == true && mounted) {
                        await ApiService.deletePlaylist(pl.id);
                        Navigator.pop(context);
                      }
                    },
                    child: Container(
                      height: 46, width: 46,
                      decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.red.withOpacity(0.3))),
                      child: const Icon(Icons.delete_rounded, color: Colors.redAccent, size: 20),
                    ),
                  ),
              ]),
            ),
          ),

          // ── Song list ────────────────────────────────────────────────
          if (_loading)
            SliverList(delegate: SliverChildBuilderDelegate(
              (_, __) => const SongTileSkeleton(), childCount: 8,
            ))
          else if (pl.songs.isEmpty)
            const SliverFillRemaining(child: EmptyState(icon: Icons.queue_music_rounded, title: 'No Songs', subtitle: 'This playlist is empty'))
          else
            SliverList(delegate: SliverChildBuilderDelegate((_, i) {
              final s = pl.songs[i];
              return SongTile(
                song: s, showIndex: true, index: i,
                onTap: () => context.read<PlayerProvider>().play(s, queue: pl.songs, index: i),
                onMore: () => showSongOptions(context, s,
                  onAddToPlaylist: () => _showAddToPlaylist(context, s),
                ),
              );
            }, childCount: pl.songs.length)),

          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),
    );
  }

  void _showAddToPlaylist(BuildContext context, Song song) async {
    final playlists = await ApiService.getMyPlaylists();
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: kCard,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 12),
        const Text('Add to Playlist', style: TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 8),
        ...playlists.map((p) => ListTile(
          leading: KImage(p.image, width: 44, height: 44, radius: 8),
          title: Text(p.name, style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w600)),
          onTap: () async {
            await ApiService.addToPlaylist(p.id, song);
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Added to ${p.name}', style: const TextStyle(fontFamily: kFont)),
              backgroundColor: kPrimary,
            ));
          },
        )),
        const SizedBox(height: 12),
      ]),
    );
  }
}
