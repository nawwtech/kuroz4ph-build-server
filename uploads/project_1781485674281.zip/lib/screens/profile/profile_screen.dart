import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../utils/theme.dart';
import '../../widgets/widgets.dart';
import '../auth/login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg, elevation: 0, automaticallyImplyLeading: false,
        title: const Text('Profile', style: TextStyle(fontFamily: kFont, fontWeight: FontWeight.w900, fontSize: 22)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Profile header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kPrimary.withOpacity(0.2), kCard]),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kPrimary.withOpacity(0.2)),
            ),
            child: Row(children: [
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [kPrimary, kPrimary2]),
                  boxShadow: [BoxShadow(color: kPrimary.withOpacity(0.4), blurRadius: 16)],
                ),
                child: Center(child: Text(
                  (user?.displayName ?? user?.username ?? '?')[0].toUpperCase(),
                  style: const TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900),
                )),
              ),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(user?.displayName ?? user?.username ?? 'User',
                  style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 20, fontWeight: FontWeight.w900)),
                Text('@${user?.username ?? ''}', style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 13)),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: kPrimary.withOpacity(0.15), borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: kPrimary.withOpacity(0.4)),
                  ),
                  child: Text((user?.plan ?? 'free').toUpperCase(),
                    style: const TextStyle(fontFamily: kFont, color: kPrimary, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1)),
                ),
              ])),
            ]),
          ),
          const SizedBox(height: 24),

          // Settings section
          _sectionTitle('Settings'),
          _tile(Icons.person_rounded, 'Edit Profile', onTap: () {}),
          _tile(Icons.notifications_rounded, 'Notifications', onTap: () {}),
          _tile(Icons.high_quality_rounded, 'Audio Quality', onTap: () {}),
          _tile(Icons.download_rounded, 'Downloads', onTap: () {}),
          _tile(Icons.storage_rounded, 'Cache', trailing: const Text('Clear', style: TextStyle(fontFamily: kFont, color: kPrimary, fontSize: 13)), onTap: () {}),

          const SizedBox(height: 16),
          _sectionTitle('About'),
          _tile(Icons.info_rounded, 'Kurofy v1.0.0', onTap: () {}),
          _tile(Icons.code_rounded, 'Developer', trailing: const Text('@kuroz4ph', style: TextStyle(fontFamily: kFont, color: kPrimary, fontSize: 13)),
            onTap: () {}),

          const SizedBox(height: 24),
          GestureDetector(
            onTap: () async {
              await context.read<AuthProvider>().logout();
              if (context.mounted) {
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
              }
            },
            child: Container(
              width: double.infinity, height: 52,
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.red.withOpacity(0.35)),
              ),
              child: const Center(child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.logout_rounded, color: Colors.redAccent, size: 20),
                SizedBox(width: 8),
                Text('Logout', style: TextStyle(fontFamily: kFont, color: Colors.redAccent, fontWeight: FontWeight.w800, fontSize: 16)),
              ])),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _sectionTitle(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(t, style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
  );

  Widget _tile(IconData icon, String title, {Widget? trailing, required VoidCallback onTap}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
      child: ListTile(
        leading: Icon(icon, color: kTextSub, size: 20),
        title: Text(title, style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 14, fontWeight: FontWeight.w600)),
        trailing: trailing ?? const Icon(Icons.chevron_right_rounded, color: kTextMuted, size: 20),
        onTap: onTap, dense: true,
      ),
    );
  }
}
