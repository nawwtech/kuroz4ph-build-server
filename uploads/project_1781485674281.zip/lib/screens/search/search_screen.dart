import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/models.dart';
import '../../providers/player_provider.dart';
import '../../services/api_service.dart';
import '../../utils/theme.dart';
import '../../widgets/widgets.dart';
import '../artist/artist_screen.dart';
import '../album/album_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> with SingleTickerProviderStateMixin {
  final _ctrl = TextEditingController();
  late TabController _tabCtrl;

  List<Song>     _songs     = [];
  List<Artist>   _artists   = [];
  List<Album>    _albums    = [];
  bool _loading = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() { _tabCtrl.dispose(); _ctrl.dispose(); super.dispose(); }

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) { setState(() { _songs = []; _artists = []; _albums = []; }); return; }
    setState(() { _loading = true; _query = q; });
    try {
      final res = await ApiService.searchAll(q);
      if (mounted) setState(() {
        _songs   = (res['songs']   as List? ?? []).map((e) => Song.fromJson(e)).toList();
        _artists = (res['artists'] as List? ?? []).map((e) => Artist.fromJson(e)).toList();
        _albums  = (res['albums']  as List? ?? []).map((e) => Album.fromJson(e)).toList();
        _loading = false;
      });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg, elevation: 0,
        title: Container(
          height: 44,
          decoration: BoxDecoration(color: kCardLight, borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
          child: TextField(
            controller: _ctrl, autofocus: true,
            style: const TextStyle(color: kText, fontFamily: kFont, fontSize: 15),
            onChanged: (v) { if (v.length > 1) _search(v); else setState(() { _songs = []; _artists = []; _albums = []; }); },
            onSubmitted: _search,
            decoration: const InputDecoration(
              hintText: 'Search songs, artists, albums...',
              hintStyle: TextStyle(color: kTextMuted, fontFamily: kFont, fontSize: 13),
              prefixIcon: Icon(Icons.search_rounded, color: kTextMuted, size: 20),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        bottom: _query.isNotEmpty ? TabBar(
          controller: _tabCtrl,
          indicatorColor: kPrimary, labelColor: kPrimary, unselectedLabelColor: kTextSub,
          labelStyle: const TextStyle(fontFamily: kFont, fontWeight: FontWeight.w700, fontSize: 13),
          tabs: [
            Tab(text: 'SONGS (${_songs.length})'),
            Tab(text: 'ARTISTS (${_artists.length})'),
            Tab(text: 'ALBUMS (${_albums.length})'),
          ],
        ) : null,
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: kPrimary))
        : _query.isEmpty
          ? _buildEmptySearch()
          : TabBarView(controller: _tabCtrl, children: [
              _buildSongs(), _buildArtists(), _buildAlbums(),
            ]),
    );
  }

  Widget _buildEmptySearch() {
    return const EmptyState(
      icon: Icons.search_rounded,
      title: 'Search Kurofy',
      subtitle: 'Find your favorite songs, artists and albums',
    );
  }

  Widget _buildSongs() {
    if (_songs.isEmpty) return const EmptyState(icon: Icons.music_off_rounded, title: 'No Songs Found', subtitle: 'Try a different keyword');
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 100),
      itemCount: _songs.length,
      itemBuilder: (_, i) {
        final s = _songs[i];
        return SongTile(
          song: s,
          onTap: () => context.read<PlayerProvider>().play(s, queue: _songs, index: i),
          onMore: () => showSongOptions(context, s),
        );
      },
    );
  }

  Widget _buildArtists() {
    if (_artists.isEmpty) return const EmptyState(icon: Icons.person_off_rounded, title: 'No Artists Found', subtitle: 'Try a different keyword');
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 16, childAspectRatio: 0.75,
      ),
      itemCount: _artists.length,
      itemBuilder: (_, i) {
        final a = _artists[i];
        return GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ArtistScreen(artistId: a.id))),
          child: Column(children: [
            ClipOval(child: KImage(a.image, width: 90, height: 90, radius: 45)),
            const SizedBox(height: 8),
            Text(a.name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
              style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 12)),
          ]),
        );
      },
    );
  }

  Widget _buildAlbums() {
    if (_albums.isEmpty) return const EmptyState(icon: Icons.album_rounded, title: 'No Albums Found', subtitle: 'Try a different keyword');
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 0.75,
      ),
      itemCount: _albums.length,
      itemBuilder: (_, i) {
        final a = _albums[i];
        return GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AlbumScreen(albumId: a.id))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            KImage(a.image, width: double.infinity, height: 160, radius: 14),
            const SizedBox(height: 8),
            Text(a.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 13)),
            Text(a.artists, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 11)),
          ]),
        );
      },
    );
  }
}
