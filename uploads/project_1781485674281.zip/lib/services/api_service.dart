import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';
import '../utils/theme.dart';

class ApiService {
  static String get _base => kApiBase;

  static Future<String?> get _token async {
    final p = await SharedPreferences.getInstance();
    return p.getString('token');
  }

  static Future<Map<String, String>> get _headers async {
    final t = await _token;
    return {
      'Content-Type': 'application/json',
      if (t != null) 'Authorization': 'Bearer $t',
    };
  }

  static Future<dynamic> _get(String path) async {
    final res = await http.get(Uri.parse('$_base$path'), headers: await _headers)
        .timeout(const Duration(seconds: 15));
    return jsonDecode(res.body);
  }

  static Future<dynamic> _post(String path, Map body) async {
    final res = await http.post(Uri.parse('$_base$path'),
        headers: await _headers, body: jsonEncode(body))
        .timeout(const Duration(seconds: 15));
    return jsonDecode(res.body);
  }

  static Future<dynamic> _put(String path, Map body) async {
    final res = await http.put(Uri.parse('$_base$path'),
        headers: await _headers, body: jsonEncode(body))
        .timeout(const Duration(seconds: 15));
    return jsonDecode(res.body);
  }

  static Future<dynamic> _delete(String path) async {
    final res = await http.delete(Uri.parse('$_base$path'), headers: await _headers)
        .timeout(const Duration(seconds: 15));
    return jsonDecode(res.body);
  }

  // ── Auth ─────────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> login(String username, String password) async {
    return await _post('/auth/login', {'username': username, 'password': password});
  }

  static Future<Map<String, dynamic>> register(String username, String email, String password) async {
    return await _post('/auth/register', {'username': username, 'email': email, 'password': password});
  }

  // ── Music ────────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> getHome() async {
    final d = await _get('/music/home');
    return d['data'] ?? {};
  }

  static Future<List<Song>> getTrending() async {
    final d = await _get('/music/trending');
    return ((d['data'] ?? []) as List).map((e) => Song.fromJson(e)).toList();
  }

  static Future<List<Album>> getNewReleases() async {
    final d = await _get('/music/new-releases');
    return ((d['data'] ?? []) as List).map((e) => Album.fromJson(e)).toList();
  }

  static Future<List<Playlist>> getCharts() async {
    final d = await _get('/music/charts');
    return ((d['data'] ?? []) as List).map((e) => Playlist.fromJson(e)).toList();
  }

  static Future<Song?> getSong(String id) async {
    final d = await _get('/music/song/$id');
    return d['data'] != null ? Song.fromJson(d['data']) : null;
  }

  static Future<List<Song>> getSuggestions(String id) async {
    final d = await _get('/music/song/$id/suggestions');
    return ((d['data'] ?? []) as List).map((e) => Song.fromJson(e)).toList();
  }

  static Future<String> getLyrics(String id) async {
    final d = await _get('/music/song/$id/lyrics');
    return d['data'] ?? '';
  }

  // ── Search ────────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> searchAll(String q) async {
    final d = await _get('/search?q=${Uri.encodeComponent(q)}');
    return d['data'] ?? {};
  }

  static Future<List<Song>> searchSongs(String q, {int page = 1}) async {
    final d = await _get('/search/songs?q=${Uri.encodeComponent(q)}&page=$page');
    return ((d['data'] ?? []) as List).map((e) => Song.fromJson(e)).toList();
  }

  static Future<List<Artist>> searchArtists(String q) async {
    final d = await _get('/search/artists?q=${Uri.encodeComponent(q)}');
    return ((d['data'] ?? []) as List).map((e) => Artist.fromJson(e)).toList();
  }

  static Future<List<Album>> searchAlbums(String q) async {
    final d = await _get('/search/albums?q=${Uri.encodeComponent(q)}');
    return ((d['data'] ?? []) as List).map((e) => Album.fromJson(e)).toList();
  }

  // ── Artist ────────────────────────────────────────────────────────────────
  static Future<Artist?> getArtist(String id) async {
    final d = await _get('/artist/$id');
    return d['data'] != null ? Artist.fromJson(d['data']) : null;
  }

  // ── Album ─────────────────────────────────────────────────────────────────
  static Future<Album?> getAlbum(String id) async {
    final d = await _get('/album/$id');
    return d['data'] != null ? Album.fromJson(d['data']) : null;
  }

  // ── Playlist ──────────────────────────────────────────────────────────────
  static Future<List<Playlist>> getMyPlaylists() async {
    final d = await _get('/playlist/my');
    return ((d['data'] ?? []) as List).map((e) => Playlist.fromJson(e)).toList();
  }

  static Future<Playlist?> getPlaylist(String id) async {
    final d = await _get('/playlist/$id');
    return d['data'] != null ? Playlist.fromJson(d['data']) : null;
  }

  static Future<Playlist?> getSaavnPlaylist(String id) async {
    final d = await _get('/playlist/saavn/$id');
    return d['data'] != null ? Playlist.fromJson(d['data']) : null;
  }

  static Future<bool> createPlaylist(String name, {String desc = '', bool isPublic = true}) async {
    final d = await _post('/playlist', {'name': name, 'description': desc, 'isPublic': isPublic});
    return d['success'] == true;
  }

  static Future<bool> updatePlaylist(String id, Map<String, dynamic> data) async {
    final d = await _put('/playlist/$id', data);
    return d['success'] == true;
  }

  static Future<bool> deletePlaylist(String id) async {
    final d = await _delete('/playlist/$id');
    return d['success'] == true;
  }

  static Future<bool> addToPlaylist(String playlistId, Song song) async {
    final d = await _post('/playlist/$playlistId/songs', {'song': song.toJson()});
    return d['success'] == true;
  }

  static Future<bool> removeFromPlaylist(String playlistId, String songId) async {
    final d = await _delete('/playlist/$playlistId/songs/$songId');
    return d['success'] == true;
  }

  // ── User ──────────────────────────────────────────────────────────────────
  static Future<UserModel?> getProfile() async {
    final d = await _get('/user/profile');
    return d['data'] != null ? UserModel.fromJson(d['data']) : null;
  }

  static Future<List<Song>> getLiked() async {
    final d = await _get('/user/liked');
    return ((d['data'] ?? []) as List).map((e) => Song.fromJson((e['song'] ?? e) as Map<String, dynamic>)).toList();
  }

  static Future<void> likeSong(Song song) => _post('/user/liked', {'song': song.toJson()});
  static Future<void> unlikeSong(String id) => _delete('/user/liked/$id');
  static Future<bool> checkLiked(String id) async {
    final d = await _get('/user/liked/$id/check');
    return d['liked'] == true;
  }

  static Future<List<Song>> getHistory() async {
    final d = await _get('/user/history');
    return ((d['data'] ?? []) as List).map((e) => Song.fromJson((e['song'] ?? e) as Map<String, dynamic>)).toList();
  }

  static Future<void> addHistory(Song song) => _post('/user/history', {'song': song.toJson()});

  static Future<void> followItem(Map<String, dynamic> item) => _post('/user/following', {'item': item});
  static Future<void> unfollowItem(String id) => _delete('/user/following/$id');
  static Future<bool> checkFollowing(String id) async {
    final d = await _get('/user/following/$id/check');
    return d['following'] == true;
  }
}
