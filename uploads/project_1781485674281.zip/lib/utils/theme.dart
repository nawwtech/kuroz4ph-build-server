import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ── Colors ───────────────────────────────────────────────────────────────────
const kBg        = Color(0xFF0A0A0F);
const kCard      = Color(0xFF111118);
const kCardLight = Color(0xFF1A1A24);
const kBorder    = Color(0xFF1E1E2E);
const kPrimary   = Color(0xFF6C63FF);   // Purple Kurofy
const kPrimary2  = Color(0xFF4FC3F7);   // Blue accent
const kAccent    = Color(0xFFFF6B9D);   // Pink accent
const kGreen     = Color(0xFF1DB954);   // Spotify-like green
const kYellow    = Color(0xFFFFD60A);
const kText      = Colors.white;
const kTextSub   = Color(0xFF9E9E9E);
const kTextMuted = Color(0xFF555565);

// ── Fonts ────────────────────────────────────────────────────────────────────
const kFont  = 'Rajdhani';
const kFont2 = 'Rajdhani';

// ── API Base URL — ganti sesuai server kamu ───────────────────────────────────
const kApiBase = 'http://gwenleslie.rexzystr.my.id:5008/api';

// ── Theme ────────────────────────────────────────────────────────────────────
ThemeData get kTheme => ThemeData(
  brightness:        Brightness.dark,
  scaffoldBackgroundColor: kBg,
  primaryColor:      kPrimary,
  colorScheme: const ColorScheme.dark(
    primary:   kPrimary,
    secondary: kPrimary2,
    surface:   kCard,
    background: kBg,
  ),
  fontFamily: kFont,
  textTheme: TextTheme(
    displayLarge:  _ts(32, FontWeight.w900, kText),
    displayMedium: _ts(28, FontWeight.w900, kText),
    displaySmall:  _ts(24, FontWeight.w800, kText),
    headlineLarge: _ts(22, FontWeight.w800, kText),
    headlineMedium:_ts(20, FontWeight.w700, kText),
    headlineSmall: _ts(18, FontWeight.w700, kText),
    titleLarge:    _ts(17, FontWeight.w700, kText),
    titleMedium:   _ts(15, FontWeight.w600, kText),
    titleSmall:    _ts(13, FontWeight.w600, kText),
    bodyLarge:     _ts(15, FontWeight.w400, kText),
    bodyMedium:    _ts(13, FontWeight.w400, kTextSub),
    bodySmall:     _ts(11, FontWeight.w400, kTextMuted),
    labelLarge:    _ts(14, FontWeight.w700, kText),
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: kBg,
    elevation: 0,
    iconTheme: IconThemeData(color: kText),
    titleTextStyle: TextStyle(
      fontFamily: kFont, color: kText, fontSize: 18, fontWeight: FontWeight.w800,
    ),
  ),
  bottomNavigationBarTheme: const BottomNavigationBarThemeData(
    backgroundColor: Color(0xFF0E0E18),
    selectedItemColor: kPrimary,
    unselectedItemColor: kTextMuted,
    type: BottomNavigationBarType.fixed,
    elevation: 0,
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: kCardLight,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide.none,
    ),
    hintStyle: const TextStyle(color: kTextMuted, fontFamily: kFont),
  ),
  sliderTheme: const SliderThemeData(
    thumbColor: kPrimary,
    activeTrackColor: kPrimary,
    inactiveTrackColor: kBorder,
    trackHeight: 3,
    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 6),
    overlayShape: RoundSliderOverlayShape(overlayRadius: 16),
  ),
  cardTheme: CardTheme(
    color: kCard,
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
  ),
);

TextStyle _ts(double size, FontWeight w, Color c) =>
    TextStyle(fontFamily: kFont, fontSize: size, fontWeight: w, color: c);
