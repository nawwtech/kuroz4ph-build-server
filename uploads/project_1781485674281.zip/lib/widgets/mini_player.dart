import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/player_provider.dart';
import '../utils/theme.dart';
import '../widgets/widgets.dart';
import 'player/full_player_screen.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    if (!player.showMini || player.current == null) return const SizedBox.shrink();

    final song = player.current!;

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FullPlayerScreen())),
      child: Container(
        height: 68,
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 8),
        decoration: BoxDecoration(
          color: kCardLight,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kPrimary.withOpacity(0.25)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 4))],
        ),
        child: Stack(children: [
          // Progress bar
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
              child: LinearProgressIndicator(
                value: player.progress.clamp(0.0, 1.0),
                backgroundColor: kBorder,
                valueColor: const AlwaysStoppedAnimation<Color>(kPrimary),
                minHeight: 2,
              ),
            ),
          ),
          // Content
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(children: [
              // Cover
              Hero(tag: 'player_cover', child: KImage(song.image, width: 48, height: 48, radius: 10)),
              const SizedBox(width: 12),
              // Info
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 14)),
                Text(song.artists, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 11)),
              ])),
              // Controls
              Row(children: [
                IconButton(
                  icon: const Icon(Icons.skip_previous_rounded, color: kText, size: 26),
                  onPressed: () => context.read<PlayerProvider>().previous(),
                  padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                ),
                GestureDetector(
                  onTap: () => context.read<PlayerProvider>().togglePlay(),
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [kPrimary, kPrimary2]),
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: kPrimary.withOpacity(0.4), blurRadius: 8)],
                    ),
                    child: Icon(
                      player.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                      color: Colors.white, size: 22,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.skip_next_rounded, color: kText, size: 26),
                  onPressed: () => context.read<PlayerProvider>().next(),
                  padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                ),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}
