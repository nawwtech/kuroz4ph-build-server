import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';
import '../utils/theme.dart';
import '../models/models.dart';

// ── Skeleton loader ───────────────────────────────────────────────────────────
class SkeletonBox extends StatelessWidget {
  final double width, height, radius;
  const SkeletonBox({super.key, required this.width, required this.height, this.radius = 8});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: kCardLight, highlightColor: kBorder,
      child: Container(
        width: width, height: height,
        decoration: BoxDecoration(color: kCardLight, borderRadius: BorderRadius.circular(radius)),
      ),
    );
  }
}

class SongTileSkeleton extends StatelessWidget {
  const SongTileSkeleton({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(children: [
        SkeletonBox(width: 52, height: 52, radius: 10),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SkeletonBox(width: 160, height: 14),
          const SizedBox(height: 6),
          SkeletonBox(width: 100, height: 11),
        ])),
      ]),
    );
  }
}

// ── Net image ─────────────────────────────────────────────────────────────────
class KImage extends StatelessWidget {
  final String url;
  final double? width, height;
  final double radius;
  final BoxFit fit;
  const KImage(this.url, {super.key, this.width, this.height, this.radius = 8, this.fit = BoxFit.cover});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: url.isEmpty
          ? _placeholder()
          : CachedNetworkImage(
              imageUrl: url, width: width, height: height, fit: fit,
              placeholder: (_, __) => _placeholder(),
              errorWidget: (_, __, ___) => _placeholder(),
            ),
    );
  }

  Widget _placeholder() => Container(
    width: width, height: height,
    color: kCardLight,
    child: const Icon(Icons.music_note_rounded, color: kTextMuted, size: 24),
  );
}

// ── Song tile ─────────────────────────────────────────────────────────────────
class SongTile extends StatelessWidget {
  final Song song;
  final VoidCallback onTap;
  final VoidCallback? onMore;
  final bool isPlaying;
  final bool showIndex;
  final int? index;

  const SongTile({
    super.key, required this.song, required this.onTap,
    this.onMore, this.isPlaying = false, this.showIndex = false, this.index,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(children: [
          if (showIndex && index != null)
            SizedBox(width: 28, child: Text('${index! + 1}', style: TextStyle(
              fontFamily: kFont, color: isPlaying ? kPrimary : kTextMuted, fontSize: 13, fontWeight: FontWeight.w600,
            ))),
          Stack(
            alignment: Alignment.center,
            children: [
              KImage(song.image, width: 52, height: 52, radius: 10),
              if (isPlaying)
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    color: Colors.black45, borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.equalizer_rounded, color: kPrimary, size: 22),
                ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontFamily: kFont, color: isPlaying ? kPrimary : kText, fontWeight: FontWeight.w700, fontSize: 14)),
            const SizedBox(height: 3),
            Text('${song.artists}${song.album.isNotEmpty ? ' • ${song.album}' : ''}',
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12)),
          ])),
          if (onMore != null)
            IconButton(
              icon: const Icon(Icons.more_vert_rounded, color: kTextMuted, size: 20),
              onPressed: onMore,
              padding: EdgeInsets.zero, constraints: const BoxConstraints(),
            ),
        ]),
      ),
    );
  }
}

// ── Section header ────────────────────────────────────────────────────────────
class SectionHeader extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onAction;
  const SectionHeader({super.key, required this.title, this.action, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 14),
      child: Row(children: [
        Expanded(child: Text(title, style: const TextStyle(
          fontFamily: kFont, color: kText, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 0.5,
        ))),
        if (action != null)
          GestureDetector(
            onTap: onAction,
            child: Text(action!, style: const TextStyle(fontFamily: kFont, color: kPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
          ),
      ]),
    );
  }
}

// ── Card horizontal scroll ────────────────────────────────────────────────────
class AlbumCard extends StatelessWidget {
  final String title, subtitle, image;
  final VoidCallback onTap;
  final double size;
  const AlbumCard({super.key, required this.title, required this.subtitle, required this.image, required this.onTap, this.size = 140});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        margin: const EdgeInsets.only(right: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          KImage(image, width: size, height: size, radius: 12),
          const SizedBox(height: 8),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 2),
          Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 11)),
        ]),
      ),
    );
  }
}

class ArtistCard extends StatelessWidget {
  final Artist artist;
  final VoidCallback onTap;
  const ArtistCard({super.key, required this.artist, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 110,
        margin: const EdgeInsets.only(right: 14),
        child: Column(children: [
          ClipOval(child: KImage(artist.image, width: 90, height: 90, radius: 45)),
          const SizedBox(height: 8),
          Text(artist.name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
            style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 12)),
        ]),
      ),
    );
  }
}

// ── Gradient app bar ──────────────────────────────────────────────────────────
class KAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final bool showBack;
  const KAppBar({super.key, required this.title, this.actions, this.showBack = true});

  @override
  Size get preferredSize => const Size.fromHeight(56);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: kBg, elevation: 0,
      automaticallyImplyLeading: showBack,
      title: Text(title, style: const TextStyle(fontFamily: kFont, fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 1)),
      actions: actions,
    );
  }
}

// ── Empty state ───────────────────────────────────────────────────────────────
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: kTextMuted, size: 64),
          const SizedBox(height: 16),
          Text(title, style: const TextStyle(fontFamily: kFont, color: kText, fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 13)),
        ]),
      ),
    );
  }
}

// ── Song more bottom sheet ────────────────────────────────────────────────────
void showSongOptions(BuildContext context, Song song, {
  VoidCallback? onAddToPlaylist,
  VoidCallback? onLike,
  VoidCallback? onDownload,
  VoidCallback? onShare,
  bool isLiked = false,
}) {
  showModalBottomSheet(
    context: context,
    backgroundColor: kCard,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (_) => Padding(
      padding: const EdgeInsets.fromLTRB(0, 8, 0, 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 36, height: 4, decoration: BoxDecoration(color: kBorder, borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 16),
        // Song info
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(children: [
            KImage(song.image, width: 52, height: 52, radius: 10),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontFamily: kFont, color: kText, fontWeight: FontWeight.w700, fontSize: 14)),
              Text(song.artists, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontFamily: kFont, color: kTextSub, fontSize: 12)),
            ])),
          ]),
        ),
        const SizedBox(height: 8),
        const Divider(color: kBorder, height: 1),
        const SizedBox(height: 8),
        _option(Icons.favorite_rounded, isLiked ? 'Unlike Song' : 'Like Song', onLike, color: isLiked ? Colors.red : null),
        _option(Icons.playlist_add_rounded, 'Add to Playlist', onAddToPlaylist),
        _option(Icons.download_rounded, 'Download', onDownload),
        _option(Icons.share_rounded, 'Share', onShare),
      ]),
    ),
  );
}

Widget _option(IconData icon, String label, VoidCallback? onTap, {Color? color}) {
  return ListTile(
    leading: Icon(icon, color: color ?? kTextSub, size: 22),
    title: Text(label, style: TextStyle(fontFamily: kFont, color: color ?? kText, fontSize: 15, fontWeight: FontWeight.w600)),
    onTap: () => onTap?.call(),
    dense: true,
  );
}
